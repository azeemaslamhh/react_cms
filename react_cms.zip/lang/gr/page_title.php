<?php

    return [
        'dashboard'=>'Armaturenbrett',
        'demo_one'=>'Demo 1',
        'demo_two'=>'Demo 2',
        'demo_three'=>'Demo 3',
        'demo_four'=>'Demo 4',
        'demo_six'=>'Demo 6',
        'demo_seven'=>'Demo 7',
        'demo_eight'=>'Demo 8',
        'demo_nine'=>'Demo 9',
        'demo_ten'=>'Demo 10',
        'demo_five'=>'Willkommen beim Demo-Dashboard',
        'social_media'=>'Social Media Dashboard',
        'fintech'=>'Finanz-Dashboard',
        'performance'=>'Website-Leistungs-Dashboard',
        'ecommerce'=>'E-Commerce-Dashboard',
        'crm'=>'CRM',
        'sales_performance'=>'Umsatzentwicklung',

        'changelog' => 'Änderungsprotokoll',

        'support_ticket' => 'Alle Support-Tickets',
        'ticket_detail' => 'Ticketdetails',
        'new_ticket'=>'Neues Ticket',

        'job_search' => 'Arbeitssuche',
        'job_search_list' => 'Listenansicht',
        'job_detail' =>'Auftragsdetails',
        'job_apply' => 'Stellenbewerbung',

        'inbox' => 'Posteingang',
        'read_email' => 'E-Mail lesen',

        'chat'=>'Plaudern',
    ];