<?php

    return [
        'dashboard'=>'Dashboard',
        'demo_one'=>'Demo 1',
        'demo_two'=>'Demo 2',
        'demo_three'=>'Demo 3',
        'demo_four'=>'Demo 4',
        'demo_six'=>'Demo 6',
        'demo_seven'=>'Demo 7',
        'demo_eight'=>'Demo 8',
        'demo_nine'=>'Demo 9',
        'demo_ten'=>'Demo 10',
        'demo_five'=>'Welcome To Demo Dashboard',
        'social_media'=>'Social Media Dashboard',
        'fintech'=>'Finance Dashboard',
        'performance'=>'Website Performance Dashboard',
        'ecommerce'=>'Ecommerce Dashboard',
        'crm'=>'CRM',
        'sales_performance'=>'Sales Performance',

        'changelog' => 'Changelog',

        'support_ticket' => 'All Support Ticket',
        'ticket_detail' => 'Ticket Details',
        'new_ticket'=>'New Ticket',

        'job_search' => 'Job Search',
        'job_search_list'=>'List View',
        'job_detail' =>'Job Detail',
        'job_apply' => 'Job Apply',

        'inbox' => 'Inbox',
        'read_email' => 'Read Email',

        'chat'=>'Chat',

    ];