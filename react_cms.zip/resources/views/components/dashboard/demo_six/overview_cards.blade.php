<div class="col-xxl-3 col-sm-6 mb-25">
    <!-- Card 1  -->
    <div class="ap-po-details ap-po-details--2 p-25 radius-xl d-flex justify-content-between">
        <div class="overview-content w-100">
            <div class=" ap-po-details-content d-flex flex-wrap justify-content-between">
                <div class="ap-po-details__titlebar">
                    <h1>100+</h1>
                    <p>Total Products</p>
                </div>
                <div class="ap-po-details__icon-area">
                    <div class="svg-icon order-bg-opacity-primary color-primary">

                        <i class="uil uil-briefcase-alt"></i>
                    </div>
                </div>
            </div>
            <div class="ap-po-details-time">
                <span class="color-success"><i class="las la-arrow-up"></i>
                    <strong>25.36%</strong></span>
                <small>Since last month</small>
            </div>
        </div>

    </div>
    <!-- Card 1 End  -->
</div>
<div class="col-xxl-3 col-sm-6 mb-25">
    <!-- Card 2 -->
    <div class="ap-po-details ap-po-details--2 p-25 radius-xl d-flex justify-content-between">
        <div class="overview-content w-100">
            <div class=" ap-po-details-content d-flex flex-wrap justify-content-between">
                <div class="ap-po-details__titlebar">
                    <h1>30,825</h1>
                    <p>Total Orders</p>
                </div>
                <div class="ap-po-details__icon-area">
                    <div class="svg-icon order-bg-opacity-info color-info">

                        <i class="uil uil-shopping-cart-alt"></i>
                    </div>
                </div>
            </div>
            <div class="ap-po-details-time">
                <span class="color-success"><i class="las la-arrow-up"></i>
                    <strong>25.36%</strong></span>
                <small>Since last month</small>
            </div>
        </div>

    </div>
    <!-- Card 2 End  -->
</div>
<div class="col-xxl-3 col-sm-6 mb-25">
    <!-- Card 3 -->
    <div class="ap-po-details ap-po-details--2 p-25 radius-xl d-flex justify-content-between">
        <div class="overview-content w-100">
            <div class=" ap-po-details-content d-flex flex-wrap justify-content-between">
                <div class="ap-po-details__titlebar">
                    <h1>$30,825</h1>
                    <p>Total Sales</p>
                </div>
                <div class="ap-po-details__icon-area">
                    <div class="svg-icon order-bg-opacity-secondary color-secondary">

                        <i class="uil uil-usd-circle"></i>
                    </div>
                </div>
            </div>
            <div class="ap-po-details-time">
                <span class="color-danger"><i class="las la-arrow-down"></i>
                    <strong>25.36%</strong></span>
                <small>Since last month</small>
            </div>
        </div>

    </div>
    <!-- Card 3 End  -->
</div>
<div class="col-xxl-3 col-sm-6 mb-25">
    <!-- Card 4  -->
    <div class="ap-po-details ap-po-details--2 p-25 radius-xl d-flex justify-content-between">
        <div class="overview-content w-100">
            <div class=" ap-po-details-content d-flex flex-wrap justify-content-between">
                <div class="ap-po-details__titlebar">
                    <h1>30,825</h1>
                    <p>New Customers</p>
                </div>
                <div class="ap-po-details__icon-area">
                    <div class="svg-icon order-bg-opacity-warning color-warning">

                        <i class="uil uil-users-alt"></i>
                    </div>
                </div>
            </div>
            <div class="ap-po-details-time">
                <span class="color-success"><i class="las la-arrow-up"></i>
                    <strong>25.36%</strong></span>
                <small>Since last month</small>
            </div>
        </div>

    </div>
    <!-- Card 4 End  -->
</div>
