<div class="col-xxl-4 col-lg-6 mb-25">
    <div class="card banner-feature banner-feature--5 mb-0">
    <div class="banner-feature__shape">
        <img src="{{ asset('assets/img/svg/group3320.svg') }}" alt="img" class="svg">
    </div>
    <div class="d-flex justify-content-center">
        <div class="card-body">
        <h1 class="banner-feature__heading color-white">Congratulations Jhon!</h1>
        <p class="banner-feature__para ">Best Seller on the last month.</p>
        <button class="banner-feature__btn btn color-secondary btn-md px-20 bg-white radius-xs fs-15" type="button">Learn More</button>
        </div>
    </div>
    </div>
</div>