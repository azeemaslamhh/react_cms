<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('description',$description); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="social-dash-wrap">
        <div class="row">
            <div class="col-lg-12">

                <div class="breadcrumb-main">
                    <h4 class="text-capitalize breadcrumb-title"><?php echo e(trans('menu.ie-import')); ?></h4>
                    <div class="breadcrumb-action justify-content-center flex-wrap">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i>Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('menu.ie-import')); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="">
                    <div class="dm-upload">
                        <div class="dm-upload-avatar media-import">
                            <img class="svg" src="<?php echo e(asset('assets/img/svg/upload.svg')); ?>" alt="upload">
                            <p class="color-dark fs-20">Drop File or <a href="#">Browse</a></p>
                        </div>
                        <div class="avatar-up">
                            <input type="file" name="upload-avatar-input" class="upload-avatar-input">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\hexadash\hexadash-laravel\full-version\resources\views/pages/applications/import_export/import.blade.php ENDPATH**/ ?>