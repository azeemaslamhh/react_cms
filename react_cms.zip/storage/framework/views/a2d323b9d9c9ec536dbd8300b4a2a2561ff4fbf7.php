<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('description',$description); ?>

<?php $__env->startSection('content'); ?>
<div class="demo2 mb-25 t-thead-bg">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-12">
                <div class="breadcrumb-main">
                    <h4 class="text-capitalize breadcrumb-title"><?php echo e(trans('page_title.dashboard')); ?></h4>
                    <div class="breadcrumb-action justify-content-center flex-wrap">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="uil uil-estate"></i><?php echo e(trans('page_title.dashboard')); ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('page_title.demo_two')); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('components.dashboard.demo_two.overview_cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_two.sales_revenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_two.source_revenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_two.new_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_two.best_seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\hexadash\hexadash-laravel\full-version\resources\views/pages/dashboard/demo_two.blade.php ENDPATH**/ ?>