<nav class="navbar navbar-light">
    <div class="navbar-left">
        <div class="logo-area">
            <a class="navbar-brand" href="<?php echo e(route('dashboard.demo_one',app()->getLocale())); ?>">
                <img class="dark" src="<?php echo e(asset('assets/img/logo-dark.svg')); ?>" alt="svg">
                <img class="light" src="<?php echo e(asset('assets/img/logo-white.svg')); ?>" alt="img">
            </a>
            <a href="#" class="sidebar-toggle">
                <img class="svg" src="<?php echo e(asset('assets/img/svg/align-center-alt.svg')); ?>" alt="img"></a>
        </div>
        
        <div class="top-menu">
            <div class="hexadash-top-menu position-relative">
                <ul>
                    <li class="has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/dashboards/*') ? 'active':''); ?>">Dashboard</a>
                        <ul class="subMenu">
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-one') ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_one',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-one')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-two') ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_two',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-two')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-three')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_three',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-three')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-four')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_four',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-four')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-five')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_five',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-five')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-six')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_six',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-six')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-seven')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_seven',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-seven')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-eight')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_eight',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-eight')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-nine')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_nine',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-nine')); ?></a></li>
                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/dashboards/demo-ten')  ? 'active':''); ?>" href="<?php echo e(route('dashboard.demo_ten',app()->getLocale())); ?>"><?php echo e(trans('menu.dashboard-demo-ten')); ?></a></li>
                        </ul>
                    </li>
                    <li class="has-subMenu">
                        <a href="#" class=""><?php echo e(trans('menu.layout-menu-title')); ?></a>
                        <ul class="subMenu">
                            <li class="l_sidebar">
                            <a href="#" data-layout="light"><?php echo e(trans('menu.layout-light-mode')); ?></a>
                            </li>
                            <li class="l_sidebar">
                            <a href="#" data-layout="dark"><?php echo e(trans('menu.layout-dark-mode')); ?></a>
                            </li>
                            <li class="l_navbar">
                            <a href="#" data-layout="top"><?php echo e(trans('menu.layout-top-menu')); ?></a>
                            </li>
                            <li class="layout">
                            <a href="<?php echo e(Helper::get_translation_url( 'ar' )); ?>"><?php echo e(trans('menu.layout-rtl')); ?></a>
                            </li>
                            <li class="layout">
                            <a href="<?php echo e(Helper::get_translation_url( 'en' )); ?>"><?php echo e(trans('menu.layout-ltr')); ?></a>
                            </li>
                        </ul>
                    </li>
                    <li class="has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/table/*') || Request::is(app()->getLocale().'/pages/dynamic-table') || Request::is(app()->getLocale().'/applications/job/*') || Request::is(app()->getLocale().'/applications/support/*') || Request::is(app()->getLocale().'/applications/social/profile-settings') || Request::is(app()->getLocale().'/applications/bookmark') || Request::is(app()->getLocale().'/applications/task')  || Request::is(app()->getLocale().'/applications/filemanager') || Request::is(app()->getLocale().'/applications/import_export/*') || Request::is(app()->getLocale().'/applications/kanban') || Request::is(app()->getLocale().'/applications/todo') || Request::is(app()->getLocale().'/applications/note') || Request::is(app()->getLocale().'/applications/contact/*') || Request::is(app()->getLocale().'/applications/user/*') || Request::is(app()->getLocale().'/applications/calendar') || Request::is(app()->getLocale().'/applications/project/*') || Request::is(app()->getLocale().'/applications/ecommerce/*') || Request::is(app()->getLocale().'/applications/email/*') || Request::is(app()->getLocale().'/applications/chat') ? 'active':''); ?>">Apps</a>
                        <ul class="megaMenu-wrapper megaMenu-dropdown">
                            <li>
                                <ul>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/email/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-envelope"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.email-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/email/inbox') ? 'active':''); ?>" href="<?php echo e(route('email.inbox',app()->getLocale())); ?>"><?php echo e(trans('menu.email-inbox')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/email/read') ? 'active':''); ?>" href="<?php echo e(route('email.read',app()->getLocale())); ?>"><?php echo e(trans('menu.email-read')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li>
                                    <a href="<?php echo e(route('chat',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/chat') ? 'active':''); ?>">
                                        <span class="nav-icon uil uil-chat"></span>
                                        <span class="menu-text"><?php echo e(trans('menu.chat-menu-title')); ?></span>
                                        <span class="badge badge-success menuItem rounded-circle">3</span>
                                    </a>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-bag"></span>
                                            <span class="menu-text text-initial"><?php echo e(trans('menu.ecommerce-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a href="<?php echo e(route('ecommerce.products',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/products') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-products')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.product_detail',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/product-detail') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-product-details')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.add_product',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/add-product') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-product-add')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.cart',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/cart') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-cart')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.orders',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/orders') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-orders')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.sellers',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/sellers') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-sellers')); ?></a></li>
                                            <li><a href="<?php echo e(route('ecommerce.invoice',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/ecommerce/invoice') ? 'active':''); ?>"><?php echo e(trans('menu.ecommerce-invoices')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-subMenu-left">
                                    <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/project/*') ? 'active':''); ?>">
                                        <span class="nav-icon uil uil-folder"></span>
                                        <span class="menu-text"><?php echo e(trans('menu.project-menu-title')); ?></span>
                                    </a>
                                    <ul class="subMenu">
                                        <li><a href="<?php echo e(route('project.project_list',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/project/list') ? 'active':''); ?>"><?php echo e(trans('menu.project-title')); ?></a></li>
                                        <li><a href="<?php echo e(route('project.project_detail',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/project/project-detail') ? 'active':''); ?>"><?php echo e(trans('menu.project-detail')); ?></a></li>
                                        <li><a href="<?php echo e(route('project.create_project',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/project/create') ? 'active':''); ?>"><?php echo e(trans('menu.create-project')); ?></a></li>
                                    </ul>
                                    </li>
                                    <li>
                                    <a href="<?php echo e(route('calendar',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/calendar') ? 'active':''); ?>">
                                        <span class="nav-icon uil uil-calendar-alt"></span>
                                        <span class="menu-text"><?php echo e(trans('menu.calendar-menu-title')); ?></span>
                                    </a>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-users-alt"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.user-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a href="<?php echo e(route('user.member',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/member') ? 'active':''); ?>"><?php echo e(trans('menu.user-team')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.grid',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/grid') ? 'active':''); ?>"><?php echo e(trans('menu.user-grid')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.list',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/list') ? 'active':''); ?>"><?php echo e(trans('menu.user-list')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.grid_style',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/grid-style') ? 'active':''); ?>"><?php echo e(trans('menu.user-grid-style')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.group',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/group') ? 'active':''); ?>"><?php echo e(trans('menu.user-group')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.add',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/add') ? 'active':''); ?>"><?php echo e(trans('menu.user-add')); ?></a></li>
                                            <li><a href="<?php echo e(route('user.table',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/user/table') ? 'active':''); ?>"><?php echo e(trans('menu.user-table')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/contact/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-at"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.contact-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/contact/grid') ? 'active':''); ?>" href="<?php echo e(route('contact.grid',app()->getLocale())); ?>"><?php echo e(trans('menu.contact-grid')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/contact/list') ? 'active':''); ?>" href="<?php echo e(route('contact.list',app()->getLocale())); ?>"><?php echo e(trans('menu.contact-list')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/contact/create') ? 'active':''); ?>" href="<?php echo e(route('contact.create',app()->getLocale())); ?>"><?php echo e(trans('menu.contact-list')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('note',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/note') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-clipboard-notes"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.note-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('todo',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/todo') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-check-square"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.todo-menu-title')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('kanban',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/kanban') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-expand-arrows"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.kanban-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/import_export/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-exchange"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.ie-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/import_export/import') ? 'active':''); ?>" href="<?php echo e(route('import_export.import',app()->getLocale())); ?>"><?php echo e(trans('menu.ie-import')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/import_export/export') ? 'active':''); ?>" href="<?php echo e(route('import_export.export',app()->getLocale())); ?>"><?php echo e(trans('menu.ie-export')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/import_export/export-selected') ? 'active':''); ?>" href="<?php echo e(route('import_export.export_selected',app()->getLocale())); ?>"><?php echo e(trans('menu.ie-export-selected')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('filemanager',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/filemanager') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-repeat"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.filemanager-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('task',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/task') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-lightbulb-alt"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.task-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('bookmark',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/bookmark') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-bookmark"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.bookmark-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/social/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-apps"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.social-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li class="nav-item"><a href="<?php echo e(route('social.profile',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/social/profile') ? 'active':''); ?>"><?php echo e(trans('menu.social-profile')); ?></a></li>
                                            <li><a href="<?php echo e(route('social.profile_settings',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/applications/social/profile-settings') ? 'active':''); ?>"><?php echo e(trans('menu.social-profile-setting')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/support/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-user"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.support-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/support/support-ticket') ? 'active':''); ?>" href="<?php echo e(route('support.support_ticket',app()->getLocale())); ?>"><?php echo e(trans('menu.support-ticket')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/support/support-details') ? 'active':''); ?>" href="<?php echo e(route('support.support_detail',app()->getLocale())); ?>"><?php echo e(trans('menu.support-ticket-detail')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/support/new-ticket') ? 'active':''); ?>" href="<?php echo e(route('support.new_ticket',app()->getLocale())); ?>"><?php echo e(trans('menu.support-new-ticket')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/applications/job/*') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-search"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.job-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/job/job-search') ? 'active':''); ?>" href="<?php echo e(route('job.job_search',app()->getLocale())); ?>"><?php echo e(trans('menu.job-search')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/job/job-search-list') ? 'active':''); ?>" href="<?php echo e(route('job.job_search_list',app()->getLocale())); ?>"><?php echo e(trans('menu.job-search-list')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/job/job-detail') ? 'active':''); ?>" href="<?php echo e(route('job.job_detail',app()->getLocale())); ?>"><?php echo e(trans('menu.job-detail')); ?></a></li>
                                            <li><a class="<?php echo e(Request::is(app()->getLocale().'/applications/job/job-apply') ? 'active':''); ?>" href="<?php echo e(route('job.job_apply',app()->getLocale())); ?>"><?php echo e(trans('menu.job-apply')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-subMenu-left">
                                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/table/*') || Request::is(app()->getLocale().'/pages/dynamic-table') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-table"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.table-menu-title')); ?></span>
                                        </a>
                                        <ul class="subMenu">
                                            <li><a href="<?php echo e(route('table.basic',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/table/basic') ? 'active':''); ?>"><?php echo e(trans('menu.table-basic')); ?></a></li>
                                            <li><a href="<?php echo e(route('table.data',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/table/data') ? 'active':''); ?>"><?php echo e(trans('menu.table-data')); ?></a></li>
                                            <li><a href="<?php echo e(route('pages.dynamic_table',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/dynamic-table') ? 'active':''); ?>"><?php echo e(trans('menu.dynamic-table-menu-title')); ?></a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/customer/*') ? 'active':''); ?>">Crud</a>
                        <ul class="subMenu">
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/customer/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-database"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.customer-crud-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/customer/list') ? 'active':''); ?>" href="<?php echo e(route('customer.list',app()->getLocale())); ?>"><?php echo e(trans('menu.customer-view-all')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/customer/create') ? 'active':''); ?>" href="<?php echo e(route('customer.create',app()->getLocale())); ?>"><?php echo e(trans('menu.customer-add-new')); ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/wizard/*') || Request::is(app()->getLocale().'/widget/*') || Request::is(app()->getLocale().'/map/*') || Request::is(app()->getLocale().'/form/*') || Request::is(app()->getLocale().'/chart/*') || Request::is(app()->getLocale().'/editor') || Request::is(app()->getLocale().'/icon/*') ? 'active':''); ?>">Features</a>
                        <ul class="subMenu">
                            <li>
                                <a href="<?php echo e(route('editor',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/editor') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-edit"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.editor-menu-title')); ?></span>
                                </a>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/icon/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-grid"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.icon-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a href="<?php echo e(route('icon.unicon',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/icon/unicon') ? 'active':''); ?>"><?php echo e(trans('menu.icon-unicon')); ?></a></li>
                                    <li><a href="<?php echo e(route('icon.awesome',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/icon/awesome') ? 'active':''); ?>"><?php echo e(trans('menu.icon-awesome')); ?></a></li>
                                    <li><a href="<?php echo e(route('icon.lineawesome',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/icon/lineawesome') ? 'active':''); ?>"><?php echo e(trans('menu.icon-line')); ?></a></li>
                                </ul>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/chart/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-chart"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.chart-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/chart/chartjs') ? 'active':''); ?>" href="<?php echo e(route('chart.chartjs',app()->getLocale())); ?>"><?php echo e(trans('menu.chart-js')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/chart/google') ? 'active':''); ?>" href="<?php echo e(route('chart.google',app()->getLocale())); ?>"><?php echo e(trans('menu.chart-google')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/chart/peity') ? 'active':''); ?>" href="<?php echo e(route('chart.peity',app()->getLocale())); ?>"><?php echo e(trans('menu.chart-peity')); ?></a></li>
                                </ul>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/form/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-keyhole-circle"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.form-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/form/basic') ? 'active':''); ?>" href="<?php echo e(route('form.basic',app()->getLocale())); ?>"><?php echo e(trans('menu.form-basic')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/form/layout') ? 'active':''); ?>" href="<?php echo e(route('form.layout',app()->getLocale())); ?>"><?php echo e(trans('menu.form-layout')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/form/element') ? 'active':''); ?>" href="<?php echo e(route('form.element',app()->getLocale())); ?>"><?php echo e(trans('menu.form-element')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/form/component') ? 'active':''); ?>" href="<?php echo e(route('form.component',app()->getLocale())); ?>"><?php echo e(trans('menu.form-component')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/form/validation') ? 'active':''); ?>" href="<?php echo e(route('form.validation',app()->getLocale())); ?>"><?php echo e(trans('menu.form-validation')); ?></a></li>
                                </ul>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/map/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-map"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.map-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a href="<?php echo e(route('map.google',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/map/google') ? 'active':''); ?>"><?php echo e(trans('menu.map-google')); ?></a></li>
                                    <li><a href="<?php echo e(route('map.leaflet',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/map/leaflet') ? 'active':''); ?>"><?php echo e(trans('menu.map-leaflet')); ?></a></li>
                                    <li><a href="<?php echo e(route('map.vector',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/map/vector') ? 'active':''); ?>"><?php echo e(trans('menu.map-vector')); ?></a></li>
                                </ul>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/widget/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-server"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.widget-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/widget/chart') ? 'active':''); ?>" href="<?php echo e(route('widget.chart',app()->getLocale())); ?>"><?php echo e(trans('menu.widget-chart')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/widget/mixed') ? 'active':''); ?>" href="<?php echo e(route('widget.mixed',app()->getLocale())); ?>"><?php echo e(trans('menu.widget-mixed')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/widget/card') ? 'active':''); ?>" href="<?php echo e(route('widget.card',app()->getLocale())); ?>"><?php echo e(trans('menu.widget-card')); ?></a></li>
                                </ul>
                            </li>
                            <li class="has-subMenu-left">
                                <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/wizard/*') ? 'active':''); ?>">
                                    <span class="nav-icon uil uil-square"></span>
                                    <span class="menu-text"><?php echo e(trans('menu.wizard-menu-title')); ?></span>
                                </a>
                                <ul class="subMenu">
                                    <li><a href="<?php echo e(route('wizard.one',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/wizard/one') ? 'active':''); ?>"><?php echo e(trans('menu.wizard-one')); ?></a></li>
                                    <li><a href="<?php echo e(route('wizard.two',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/wizard/two') ? 'active':''); ?>"><?php echo e(trans('menu.wizard-two')); ?></a></li>
                                    <li><a href="<?php echo e(route('wizard.three',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/wizard/three') ? 'active':''); ?>"><?php echo e(trans('menu.wizard-three')); ?></a></li>
                                    <li><a href="<?php echo e(route('wizard.four',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/wizard/four') ? 'active':''); ?>"><?php echo e(trans('menu.wizard-four')); ?></a></li>
                                    <li><a href="<?php echo e(route('wizard.five',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/wizard/five') ? 'active':''); ?>"><?php echo e(trans('menu.wizard-five')); ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="mega-item has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/pages/pricing') || Request::is(app()->getLocale().'/pages/gallery/*') || Request::is(app()->getLocale().'/changelog') ? 'active':''); ?>">Pages</a>
                        <ul class="megaMenu-wrapper megaMenu-small">
                            <li>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('changelog',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/changelog') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-arrow-growth"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.changelog-menu-title')); ?></span>
                                            <span class="badge badge-info-10 menuItem rounded-pill">1.0.1</span>
                                        </a>
                                    </li>
                                    <li><a href="<?php echo e(route('pages.gallery1',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/gallery/gallery1') ? 'active':''); ?>"><?php echo e(trans('menu.gallery-one')); ?></a></li>
                                    <li>
                                        <a href="<?php echo e(route('pages.gallery2',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/gallery/gallery2') ? 'active':''); ?>"><?php echo e(trans('menu.gallery-two')); ?></a>
                                    </li>
                                    <li>
                                    <a href="<?php echo e(route('pages.pricing',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/pricing') ? 'active':''); ?>">
                                        <span class="nav-icon uil uil-bill"></span>
                                        <span class="menu-text"><?php echo e(trans('menu.pricing-menu-title')); ?></span>
                                    </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.banner',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/banner') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-thumbs-up"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.banner-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.testimonial',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/testimonial') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-book-open"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.testimonial-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.faq',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/faq') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-question-circle"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.faq-menu-title')); ?></span>
                                        </a>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(route('pages.search_result',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/search/result') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-credit-card-search"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.search-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.blank',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/blank') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-circle"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.blank-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/pages/knowledge/base') ? 'active':''); ?>" href="<?php echo e(route('pages.knowledge_base',app()->getLocale())); ?>"><?php echo e(trans('menu.knowledge-base')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/pages/knowledge/all-articles') ? 'active':''); ?>" href="<?php echo e(route('pages.all_articles',app()->getLocale())); ?>"><?php echo e(trans('menu.knowledge-all-article')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/pages/knowledge/article') ? 'active':''); ?>" href="<?php echo e(route('pages.article',app()->getLocale())); ?>"><?php echo e(trans('menu.knowledge-single-article')); ?></a></li>
                                </ul>
                            </li>
                            <li>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('pages.support',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/support/center') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-headphones"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.support-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li><a href="<?php echo e(route('pages.blog.one',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/blog/one') ? 'active':''); ?>"><?php echo e(trans('menu.blog-style-one')); ?></a></li>
                                    <li><a href="<?php echo e(route('pages.blog.two',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/blog/two') ? 'active':''); ?>"><?php echo e(trans('menu.blog-style-two')); ?></a></li>
                                    <li><a href="<?php echo e(route('pages.blog.three',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/blog/three') ? 'active':''); ?>"><?php echo e(trans('menu.blog-style-three')); ?></a></li>
                                    <li><a href="<?php echo e(route('pages.blog.detail',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/blog/detail') ? 'active':''); ?>"><?php echo e(trans('menu.blog-detail')); ?></a></li>
                                    <li>
                                        <a href="<?php echo e(route('pages.terms',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/terms-and-condition') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-question-circle"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.terms-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.maintenance',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/maintenance') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-airplay"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.maintenance-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.404',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/404') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-exclamation-triangle"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.not-found-menu-title')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pages.coming_soon',app()->getLocale())); ?>" class="<?php echo e(Request::is(app()->getLocale().'/pages/coming-soon') ? 'active':''); ?>">
                                            <span class="nav-icon uil uil-sync"></span>
                                            <span class="menu-text"><?php echo e(trans('menu.coming-soon-menu-title')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="mega-item has-subMenu">
                        <a href="#" class="<?php echo e(Request::is(app()->getLocale().'/ui/*') ? 'active':''); ?>">Components</a>
                        <ul class="megaMenu-wrapper megaMenu-wide">
                            <li>
                                <span class="mega-title">Components</span>
                                <ul>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/alert') ? 'active':''); ?>" href="<?php echo e(route('ui.alert',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-alert')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/avatar') ? 'active':''); ?>" href="<?php echo e(route('ui.avatar',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-avatar')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/badge') ? 'active':''); ?>" href="<?php echo e(route('ui.badge',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-badge')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/breadcrumps') ? 'active':''); ?>" href="<?php echo e(route('ui.breadcrumps',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-breadcrumb')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/button') ? 'active':''); ?>" href="<?php echo e(route('ui.button',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-button')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/card') ? 'active':''); ?>" href="<?php echo e(route('ui.card',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-card')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/carousel') ? 'active':''); ?>" href="<?php echo e(route('ui.carousel',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-carousel')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/checkbox') ? 'active':''); ?>" href="<?php echo e(route('ui.checkbox',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-checkbox')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/collapse') ? 'active':''); ?>" href="<?php echo e(route('ui.collapse',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-collapse')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/comments') ? 'active':''); ?>" href="<?php echo e(route('ui.comments',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-comment')); ?></a></li>

                                </ul>
                            </li>
                            <li>
                                <span class="mega-title">Components</span>
                                <ul>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/dashboard-base') ? 'active':''); ?>" href="<?php echo e(route('ui.dashboard_base',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-dashboard-base')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/datepicker') ? 'active':''); ?>" href="<?php echo e(route('ui.datepicker',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-date-picker')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/drawer') ? 'active':''); ?>" href="<?php echo e(route('ui.drawer',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-drawer')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/drag-drop') ? 'active':''); ?>" href="<?php echo e(route('ui.drag_drop',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-drag-drop')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/dropdown') ? 'active':''); ?>" href="<?php echo e(route('ui.dropdown',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-dropdown')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/empty') ? 'active':''); ?>" href="<?php echo e(route('ui.empty',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-empty')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/grid') ? 'active':''); ?>" href="<?php echo e(route('ui.grid',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-grid')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/input') ? 'active':''); ?>" href="<?php echo e(route('ui.input',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-input')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/list') ? 'active':''); ?>" href="<?php echo e(route('ui.list',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-list')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/menu') ? 'active':''); ?>" href="<?php echo e(route('ui.menu',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-menu')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/message') ? 'active':''); ?>" href="<?php echo e(route('ui.message',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-message')); ?></a></li>

                                </ul>
                            </li>
                            <li>
                                <span class="mega-title">Components</span>
                                <ul>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/modals') ? 'active':''); ?>" href="<?php echo e(route('ui.modals',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-modal')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/notification') ? 'active':''); ?>" href="<?php echo e(route('ui.notification',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-notification')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/page-header') ? 'active':''); ?>" href="<?php echo e(route('ui.page_header',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-page-header')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/pagination') ? 'active':''); ?>" href="<?php echo e(route('ui.pagination',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-pagination')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/progress') ? 'active':''); ?>" href="<?php echo e(route('ui.progress',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-progress')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/radio') ? 'active':''); ?>" href="<?php echo e(route('ui.radio',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-radio')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/rate') ? 'active':''); ?>" href="<?php echo e(route('ui.rate',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-rate')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/result') ? 'active':''); ?>" href="<?php echo e(route('ui.result',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-result')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/select') ? 'active':''); ?>" href="<?php echo e(route('ui.select',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-select')); ?></a></li>
                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/skeleton') ? 'active':''); ?>" href="<?php echo e(route('ui.skeleton',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-skeleton')); ?></a></li>

                                <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/timepicker') ? 'active':''); ?>" href="<?php echo e(route('ui.timepicker',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-time-picker')); ?></a></li>

                                </ul>
                            </li>
                            <li>
                                <span class="mega-title">Components</span>
                                <ul>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/slider') ? 'active':''); ?>" href="<?php echo e(route('ui.slider',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-slider')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/spinner') ? 'active':''); ?>" href="<?php echo e(route('ui.spinner',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-spinner')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/statistic') ? 'active':''); ?>" href="<?php echo e(route('ui.statistic',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-statistic')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/steps') ? 'active':''); ?>" href="<?php echo e(route('ui.steps',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-step')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/switch') ? 'active':''); ?>" href="<?php echo e(route('ui.switch',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-switch')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/tab') ? 'active':''); ?>" href="<?php echo e(route('ui.tab',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-tab')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/tags') ? 'active':''); ?>" href="<?php echo e(route('ui.tags',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-tag')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/timeline') ? 'active':''); ?>" href="<?php echo e(route('ui.timeline',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-timeline')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/timeline2') ? 'active':''); ?>" href="<?php echo e(route('ui.timeline2',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-timeline2')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/timeline3') ? 'active':''); ?>" href="<?php echo e(route('ui.timeline3',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-timeline3')); ?></a></li>
                                    <li><a class="<?php echo e(Request::is(app()->getLocale().'/ui/uploads') ? 'active':''); ?>" href="<?php echo e(route('ui.uploads',app()->getLocale())); ?>"><?php echo e(trans('menu.ui-upload')); ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="navbar-right">
        <ul class="navbar-right__menu">
            <li class="nav-search">
                <a href="#" class="search-toggle">
                    <i class="uil uil-search"></i>
                    <i class="uil uil-times"></i>
                </a>
                <form action="/" class="search-form-topMenu">
                    <span class="search-icon uil uil-search"></span>
                    <input class="form-control me-sm-2 box-shadow-none" type="search" placeholder="Search..." aria-label="Search">
                </form>
            </li>
            <li class="nav-message">
                <div class="dropdown-custom">
                    <a href="javascript:;" class="nav-item-toggle icon-active">
                        <img class="svg" src="<?php echo e(asset('assets/img/svg/message.svg')); ?>" alt="img">
                    </a>
                    <div class="dropdown-wrapper">
                        <h2 class="dropdown-wrapper__title">Messages <span class="badge-circle badge-success ms-1">2</span></h2>
                        <ul>
                            <li class="author-online has-new-message">
                                <div class="user-avater">
                                    <img src="<?php echo e(asset('assets/img/team-1.png')); ?>" alt="">
                                </div>
                                <div class="user-message">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">Web Design</a>
                                        <span class="time-posted">3 hrs ago</span>
                                    </p>
                                    <p>
                                        <span class="desc text-truncate" style="max-width: 215px;">Lorem ipsum
                                            dolor amet cosec Lorem ipsum</span>
                                        <span class="msg-count badge-circle badge-success badge-sm">1</span>
                                    </p>
                                </div>
                            </li>
                            <li class="author-offline has-new-message">
                                <div class="user-avater">
                                    <img src="<?php echo e(asset('assets/img/team-1.png')); ?>" alt="">
                                </div>
                                <div class="user-message">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">Web Design</a>
                                        <span class="time-posted">3 hrs ago</span>
                                    </p>
                                    <p>
                                        <span class="desc text-truncate" style="max-width: 215px;">Lorem ipsum
                                            dolor amet cosec Lorem ipsum</span>
                                        <span class="msg-count badge-circle badge-success badge-sm">1</span>
                                    </p>
                                </div>
                            </li>
                            <li class="author-online has-new-message">
                                <div class="user-avater">
                                    <img src="<?php echo e(asset('assets/img/team-1.png')); ?>" alt="">
                                </div>
                                <div class="user-message">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">Web Design</a>
                                        <span class="time-posted">3 hrs ago</span>
                                    </p>
                                    <p>
                                        <span class="desc text-truncate" style="max-width: 215px;">Lorem ipsum
                                            dolor amet cosec Lorem ipsum</span>
                                        <span class="msg-count badge-circle badge-success badge-sm">1</span>
                                    </p>
                                </div>
                            </li>
                            <li class="author-offline">
                                <div class="user-avater">
                                    <img src="<?php echo e(asset('assets/img/team-1.png')); ?>" alt="">
                                </div>
                                <div class="user-message">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">Web Design</a>
                                        <span class="time-posted">3 hrs ago</span>
                                    </p>
                                    <p>
                                        <span class="desc text-truncate" style="max-width: 215px;">Lorem ipsum
                                            dolor amet cosec Lorem ipsum</span>
                                    </p>
                                </div>
                            </li>
                            <li class="author-offline">
                                <div class="user-avater">
                                    <img src="<?php echo e(asset('assets/img/team-1.png')); ?>" alt="">
                                </div>
                                <div class="user-message">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">Web Design</a>
                                        <span class="time-posted">3 hrs ago</span>
                                    </p>
                                    <p>
                                        <span class="desc text-truncate" style="max-width: 215px;">Lorem ipsum
                                            dolor amet cosec Lorem ipsum</span>
                                    </p>
                                </div>
                            </li>
                        </ul>
                        <a href="" class="dropdown-wrapper__more">See All Message</a>
                    </div>
                </div>
            </li>
            <li class="nav-notification">
                <div class="dropdown-custom">
                    <a href="javascript:;" class="nav-item-toggle icon-active">
                        <img class="svg" src="<?php echo e(asset('assets/img/svg/alarm.svg')); ?>" alt="img">
                    </a>
                    <div class="dropdown-wrapper">
                        <h2 class="dropdown-wrapper__title">Notifications <span class="badge-circle badge-warning ms-1">4</span></h2>
                        <ul>
                            <li class="nav-notification__single nav-notification__single--unread d-flex flex-wrap">
                                <div class="nav-notification__type nav-notification__type--primary">
                                    <img src="<?php echo e(asset('assets/img/svg/inbox.svg')); ?>" alt="inbox" class="svg">
                                </div>
                                <div class="nav-notification__details">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">James</a>
                                        <span>sent you a message</span>
                                    </p>
                                    <p>
                                        <span class="time-posted">5 hours ago</span>
                                    </p>
                                </div>
                            </li>
                            <li class="nav-notification__single nav-notification__single--unread d-flex flex-wrap">
                                <div class="nav-notification__type nav-notification__type--secondary">
                                    <img src="<?php echo e(asset('assets/img/svg/upload.svg')); ?>" alt="upload" class="svg">
                                </div>
                                <div class="nav-notification__details">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">James</a>
                                        <span>sent you a message</span>
                                    </p>
                                    <p>
                                        <span class="time-posted">5 hours ago</span>
                                    </p>
                                </div>
                            </li>
                            <li class="nav-notification__single nav-notification__single--unread d-flex flex-wrap">
                                <div class="nav-notification__type nav-notification__type--success">
                                    <img src="<?php echo e(asset('assets/img/svg/log-in.svg')); ?>" alt="log-in" class="svg">
                                </div>
                                <div class="nav-notification__details">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">James</a>
                                        <span>sent you a message</span>
                                    </p>
                                    <p>
                                        <span class="time-posted">5 hours ago</span>
                                    </p>
                                </div>
                            </li>
                            <li class="nav-notification__single nav-notification__single d-flex flex-wrap">
                                <div class="nav-notification__type nav-notification__type--info">
                                    <img src="<?php echo e(asset('assets/img/svg/at-sign.svg')); ?>" alt="at-sign" class="svg">
                                </div>
                                <div class="nav-notification__details">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">James</a>
                                        <span>sent you a message</span>
                                    </p>
                                    <p>
                                        <span class="time-posted">5 hours ago</span>
                                    </p>
                                </div>
                            </li>
                            <li class="nav-notification__single nav-notification__single d-flex flex-wrap">
                                <div class="nav-notification__type nav-notification__type--danger">
                                    <img src="<?php echo e(asset('assets/img/svg/heart.svg')); ?>" alt="heart" class="svg">
                                </div>
                                <div class="nav-notification__details">
                                    <p>
                                        <a href="" class="subject stretched-link text-truncate" style="max-width: 180px;">James</a>
                                        <span>sent you a message</span>
                                    </p>
                                    <p>
                                        <span class="time-posted">5 hours ago</span>
                                    </p>
                                </div>
                            </li>
                        </ul>
                        <a href="" class="dropdown-wrapper__more">See all incoming activity</a>
                    </div>
                </div>
            </li>
            <li class="nav-settings">
                <div class="dropdown-custom">
                    <a href="javascript:;" class="nav-item-toggle">
                        <img src="<?php echo e(asset('assets/img/setting.png')); ?>" alt="img">
                    </a>
                    <div class="dropdown-wrapper dropdown-wrapper--large">
                        <ul class="list-settings">
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/mail.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">All Features</a>
                                    </h6>
                                    <p>Introducing Increment subscriptions </p>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/color-palette.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">Themes</a>
                                    </h6>
                                    <p>Third party themes that are compatible</p>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/home.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">Payments</a>
                                    </h6>
                                    <p>We handle billions of dollars</p>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/video-camera.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">Design Mockups</a>
                                    </h6>
                                    <p>Share planning visuals with clients</p>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/document.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">Content Planner</a>
                                    </h6>
                                    <p>Centralize content gethering and editing</p>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="me-3"><img src="<?php echo e(asset('assets/img/microphone.png')); ?>" alt=""></div>
                                <div class="flex-grow-1">
                                    <h6>
                                        <a href="" class="stretched-link">Diagram Maker</a>
                                    </h6>
                                    <p>Plan user flows & test scenarios</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav-flag-select">
                <div class="dropdown-custom">
                    <?php switch(app()->getLocale()):
                        case ('en'): ?>
                            <a href="javascript:;" class="nav-item-toggle"><img src="<?php echo e(asset('assets/img/eng.png')); ?>" alt="" class="rounded-circle"></a>
                            <?php break; ?>
                        <?php case ('ar'): ?>
                            <a href="javascript:;" class="nav-item-toggle"><img src="<?php echo e(asset('assets/img/iraq.png')); ?>" alt="" class="rounded-circle"></a>
                            <?php break; ?>
                        <?php case ('gr'): ?>
                            <a href="javascript:;" class="nav-item-toggle"><img src="<?php echo e(asset('assets/img/ger.png')); ?>" alt="" class="rounded-circle"></a>
                            <?php break; ?>
                        <?php default: ?>
                            <a href="javascript:;" class="nav-item-toggle"><img src="<?php echo e(asset('assets/img/eng.png')); ?>" alt="" class="rounded-circle"></a>
                            <?php break; ?>
                    <?php endswitch; ?>
                    <?php if(isset($find_customer)): ?>
                        <?php $__currentLoopData = $find_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="dropdown-wrapper dropdown-wrapper--small">
                                <a href="<?php echo e(route(Route::currentRouteName(),['en',$customer->id])); ?>"><img src="<?php echo e(asset('assets/img/eng.png')); ?>" alt=""> English</a>
                                <a href="<?php echo e(route(Route::currentRouteName(),['ar',$customer->id])); ?>"><img src="<?php echo e(asset('assets/img/iraq.png')); ?>" alt=""> Arabic</a>
                                <a href="<?php echo e(route(Route::currentRouteName(),['gr',$customer->id])); ?>"><img src="<?php echo e(asset('assets/img/ger.png')); ?>" alt=""> German</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="dropdown-wrapper dropdown-wrapper--small">
                            <a href="<?php echo e(route(Route::currentRouteName(),'en')); ?>"><img src="<?php echo e(asset('assets/img/eng.png')); ?>" alt=""> English</a>
                            <a href="<?php echo e(route(Route::currentRouteName(),'ar')); ?>"><img src="<?php echo e(asset('assets/img/iraq.png')); ?>" alt=""> Arabic</a>
                            <a href="<?php echo e(route(Route::currentRouteName(),'gr')); ?>"><img src="<?php echo e(asset('assets/img/ger.png')); ?>" alt=""> German</a>
                        </div>
                    <?php endif; ?>
                </div>
            </li>
            <li class="nav-author">
                <div class="dropdown-custom">
                    <a href="javascript:;" class="nav-item-toggle"><img src="<?php echo e(asset('assets/img/author-nav.jpg')); ?>" alt="" class="rounded-circle">
                        <?php if(Auth::check()): ?>
                            <span class="nav-item__title"><?php echo e(Auth::user()->name); ?><i class="las la-angle-down nav-item__arrow"></i></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-wrapper">
                        <div class="nav-author__info">
                            <div class="author-img">
                                <img src="<?php echo e(asset('assets/img/author-nav.jpg')); ?>" alt="" class="rounded-circle">
                            </div>
                            <div>
                                <?php if(Auth::check()): ?>
                                    <h6 class="text-capitalize"><?php echo e(Auth::user()->name); ?></h6>
                                <?php endif; ?>
                                <span>UI Designer</span>
                            </div>
                        </div>
                        <div class="nav-author__options">
                            <ul>
                                <li>
                                    <a href="">
                                        <img src="<?php echo e(asset('assets/img/svg/user.svg')); ?>" alt="user" class="svg"> Profile</a>
                                </li>
                                <li>
                                    <a href="">
                                        <img src="<?php echo e(asset('assets/img/svg/settings.svg')); ?>" alt="settings" class="svg"> Settings</a>
                                </li>
                                <li>
                                    <a href="">
                                        <img src="<?php echo e(asset('assets/img/svg/key.svg')); ?>" alt="key" class="svg"> Billing</a>
                                </li>
                                <li>
                                    <a href="">
                                        <img src="<?php echo e(asset('assets/img/svg/users.svg')); ?>" alt="users" class="svg"> Activity</a>
                                </li>
                                <li>
                                    <a href="">
                                        <img src="<?php echo e(asset('assets/img/svg/bell.svg')); ?>" alt="bell" class="svg"> Help</a>
                                </li>
                            </ul>
                            <a href="" class="nav-author__signout" onclick="event.preventDefault();document.getElementById('logout').submit();">
                                <img src="<?php echo e(asset('assets/img/svg/log-out.svg')); ?>" alt="log-out" class="svg">
                                 Sign Out</a>
                                <form style="display:none;" id="logout" action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                </form>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <div class="navbar-right__mobileAction d-md-none">
            <a href="#" class="btn-search">
                <img src="<?php echo e(asset('assets/img/svg/search.svg')); ?>" alt="search" class="svg feather-search">
                <img src="<?php echo e(asset('assets/img/svg/x.svg')); ?>" alt="x" class="svg feather-x">
            </a>
            <a href="#" class="btn-author-action">
                <img src="<?php echo e(asset('assets/img/svg/more-vertical.svg')); ?>" alt="more-vertical" class="svg"></a>
        </div>
    </div>
</nav>
<?php /**PATH D:\Wamp\www\hexadash\hexadash-laravel\full-version\resources\views/partials/_top_nav.blade.php ENDPATH**/ ?>