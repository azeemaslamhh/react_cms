<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('description',$description); ?>

<?php $__env->startSection('content'); ?>
<div class="crm mb-25">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-12">
                <div class="breadcrumb-main">
                    <h4 class="text-capitalize breadcrumb-title"><?php echo e(trans('page_title.dashboard')); ?></h4>
                    <div class="breadcrumb-action justify-content-center flex-wrap">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="uil uil-estate"></i><?php echo e(trans('page_title.dashboard')); ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('page_title.demo_one')); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('components.dashboard.demo_one.overview_cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_one.sales_report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_one.sales_growth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_one.sales_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_one.top_sale_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.demo_one.browser_state', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\react_cms\resources\views/pages/dashboard/demo_one.blade.php ENDPATH**/ ?>