<!doctype html>
<html lang=""<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e((Session::get('layout')=='rtl' ? 'rtl' : 'ltr')); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>"/>
    <title>HexaDash | <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset( 'assets/css/plugin' . Helper::rlt_ext() . '.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style' . Helper::rlt_ext() . '.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/variables' . Helper::rlt_ext() . '.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app' . Helper::rlt_ext() . '.min.css')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v3.0.0/css/line.css">
</head>
<?php /**PATH D:\Wamp\www\react_cms\resources\views/partials/_header.blade.php ENDPATH**/ ?>